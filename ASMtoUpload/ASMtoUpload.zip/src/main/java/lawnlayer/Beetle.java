package lawnlayer;

public class Beetle extends Enymy {

	public Beetle(LawnLayer lawnLayer, Cell cell) {
		super(lawnLayer, cell);
		type="beetle";
	}

	

}
