package lawnlayer;

public class Worm extends Enymy {

	public Worm(LawnLayer lawnLayer, Cell cell) {
		super(lawnLayer, cell);
		type="worm";
	}



}
